package com.example.clubmate;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ClubListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ClubAdapter adapter;
    private List<Club> clubList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_list);

        recyclerView = findViewById(R.id.recyclerViewClubs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample clubs with correct logos
        clubList = new ArrayList<>();
        clubList.add(new Club(
                "Computer Club",
                "Join us for coding, software projects, and tech events.",
                R.drawable.logo_computer
        ));
        clubList.add(new Club(
                "Debate Club",
                "Participate in debates, public speaking, and competitions.",
                R.drawable.logo_debate
        ));
        clubList.add(new Club(
                "Photography Club",
                "Learn photography, editing, and go on photo walks.",
                R.drawable.logo_photography
        ));

        adapter = new ClubAdapter(clubList);
        recyclerView.setAdapter(adapter);
    }
}



