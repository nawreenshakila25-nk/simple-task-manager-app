package com.example.clubmate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.ViewHolder> {

    private Context context;
    private List<MemberRequest> memberList;
    private OnApproveClickListener listener;

    public interface OnApproveClickListener {
        void onApproveClick(MemberRequest member);
    }

    public MemberAdapter(Context context, List<MemberRequest> memberList, OnApproveClickListener listener) {
        this.context = context;
        this.memberList = memberList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_member_request, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MemberRequest member = memberList.get(position);
        holder.tvUserId.setText("User ID: " + member.getUserId());
        holder.tvClubId.setText("Club ID: " + member.getClubId());
        holder.tvStatus.setText("Status: " + member.getStatus());

        holder.btnApprove.setOnClickListener(v -> {
            if (listener != null) listener.onApproveClick(member);
        });
    }

    @Override
    public int getItemCount() {
        return memberList.size();
    }

    // Update list after approval
    public void updateList(List<MemberRequest> newList) {
        memberList.clear();
        memberList.addAll(newList);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserId, tvClubId, tvStatus;
        Button btnApprove;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUserId = itemView.findViewById(R.id.tvUserId);
            tvClubId = itemView.findViewById(R.id.tvClubId);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            btnApprove = itemView.findViewById(R.id.btnApprove);
        }
    }
}

