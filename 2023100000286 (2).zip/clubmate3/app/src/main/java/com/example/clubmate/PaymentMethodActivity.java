package com.example.clubmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentMethodActivity extends AppCompatActivity {

    Button btnBkash, btnRocket; // You can add more methods later

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_methods);

        btnBkash = findViewById(R.id.btnBkash);
        btnRocket = findViewById(R.id.btnRocket);

        // Click Bkash → PaymentInfoActivity
        btnBkash.setOnClickListener(v -> {
            Intent intent = new Intent(PaymentMethodActivity.this, PaymentInfoActivity.class);
            intent.putExtra("paymentMethod", "Bkash");
            startActivity(intent);
        });

        // Click Rocket → PaymentInfoActivity
        btnRocket.setOnClickListener(v -> {
            Intent intent = new Intent(PaymentMethodActivity.this, PaymentInfoActivity.class);
            intent.putExtra("paymentMethod", "Rocket");
            startActivity(intent);
        });
    }
}
