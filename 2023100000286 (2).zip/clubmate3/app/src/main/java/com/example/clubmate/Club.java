package com.example.clubmate;

public class Club {
    private String name;
    private String description;
    private int logoResId;

    public Club(String name, String description, int logoResId) {
        this.name = name;
        this.description = description;
        this.logoResId = logoResId;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getLogoResId() { return logoResId; }
}



