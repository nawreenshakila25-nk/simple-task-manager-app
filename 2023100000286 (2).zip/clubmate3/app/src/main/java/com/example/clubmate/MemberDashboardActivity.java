package com.example.clubmate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MemberDashboardActivity extends AppCompatActivity {

    CardView cardClubs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard); // make sure layout has only cardClubs

        cardClubs = findViewById(R.id.cardClubs);

        // card click for Clubs
        cardClubs.setOnClickListener(v -> {
            Intent i = new Intent(MemberDashboardActivity.this, ClubListActivity.class);
            startActivity(i);
        });
    }
}
