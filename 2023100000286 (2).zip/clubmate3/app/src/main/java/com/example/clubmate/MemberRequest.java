package com.example.clubmate;

public class MemberRequest {
    private int clubId;
    private int userId;
    private String status;

    public MemberRequest() {}

    public MemberRequest(int clubId, int userId, String status) {
        this.clubId = clubId;
        this.userId = userId;
        this.status = status;
    }

    public MemberRequest(int clubId, int userId) {
        this.clubId = clubId;
        this.userId = userId;
        this.status = "Pending";
    }

    public int getClubId() { return clubId; }
    public void setClubId(int clubId) { this.clubId = clubId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "UserID: " + userId + ", ClubID: " + clubId + ", Status: " + status;
    }
}


