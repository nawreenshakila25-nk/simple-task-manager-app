package com.example.clubmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentSuccessActivity extends AppCompatActivity {

    TextView tvSuccessMessage;
    Button btnBackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_success);

        tvSuccessMessage = findViewById(R.id.tvSuccessMessage);
        btnBackHome = findViewById(R.id.btnBackHome);

        // Show success message
        tvSuccessMessage.setText("Payment Successful!\nThank you for enrolling.");

        // Back to home (ClubListActivity)
        btnBackHome.setOnClickListener(v -> {
            Intent intent = new Intent(PaymentSuccessActivity.this, ClubListActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish(); // close this page
        });
    }
}
