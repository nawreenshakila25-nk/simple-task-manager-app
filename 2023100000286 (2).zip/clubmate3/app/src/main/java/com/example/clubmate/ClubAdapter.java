package com.example.clubmate;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import com.example.clubmate.Club;

public class ClubAdapter extends RecyclerView.Adapter<ClubAdapter.ViewHolder> {

    private List<Club> clubList; // ✅ remove final if you plan to modify it later

    // Constructor
    public ClubAdapter(List<Club> clubList) {
        this.clubList = clubList;
    }

    // ViewHolder class
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvClubName;
        TextView tvClubDescription;
        ImageView ivClubLogo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvClubName = itemView.findViewById(R.id.tvClubName);
            tvClubDescription = itemView.findViewById(R.id.tvClubDescription);
            ivClubLogo = itemView.findViewById(R.id.ivClubLogo);
        }
    }

    @NonNull
    @Override
    public ClubAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_club, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ClubAdapter.ViewHolder holder, int position) {
        Club club = clubList.get(position);
        holder.tvClubName.setText(club.getName());
        holder.tvClubDescription.setText(club.getDescription());
        holder.ivClubLogo.setImageResource(club.getLogoResId());
        // Add click listener
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), AboutClubActivity.class);
            intent.putExtra("clubName", club.getName());
            intent.putExtra("clubDescription", club.getDescription());
            intent.putExtra("clubLogo", club.getLogoResId());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return clubList.size();
    }
}
