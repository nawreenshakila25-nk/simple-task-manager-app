package com.example.clubmate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "clubmate.db";
    private static final int DB_VERSION = 1;

    // Users table
    private static final String T_USERS = "users";
    private static final String U_ID = "id";
    private static final String U_NAME = "name";
    private static final String U_EMAIL = "email";
    private static final String U_PASS = "password";
    private static final String U_ROLE = "role";

    // Clubs table
    private static final String T_CLUBS = "clubs";
    private static final String C_ID = "id";
    private static final String C_NAME = "name";
    private static final String C_DESC = "description";


    // Club members table
    private static final String T_CLUB_MEMBERS = "club_members";
    private static final String CM_ID = "id";
    private static final String CM_CLUB_ID = "club_id";
    private static final String CM_USER_ID = "user_id";
    private static final String CM_STATUS = "status";

    private static final String STATUS_PENDING = "Pending";
    private static final String STATUS_APPROVED = "Approved";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("PRAGMA foreign_keys=ON;");

        // Clubs
        db.execSQL("CREATE TABLE " + T_CLUBS + " (" +
                C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                C_NAME + " TEXT, " +
                C_DESC + " TEXT)");

        // Users
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                U_NAME + " TEXT, " +
                U_EMAIL + " TEXT UNIQUE, " +
                U_PASS + " TEXT, " +
                U_ROLE + " TEXT)");

        // Default admin
        ContentValues admin = new ContentValues();
        admin.put(U_NAME, "Admin");
        admin.put(U_EMAIL, "admin@clubmate.com");
        admin.put(U_PASS, "admin123");
        admin.put(U_ROLE, "Admin");
        db.insert(T_USERS, null, admin);


        // Club members
        db.execSQL("CREATE TABLE " + T_CLUB_MEMBERS + " (" +
                CM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CM_CLUB_ID + " INTEGER, " +
                CM_USER_ID + " INTEGER, " +
                CM_STATUS + " TEXT, " +
                "FOREIGN KEY(" + CM_CLUB_ID + ") REFERENCES " + T_CLUBS + "(" + C_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + CM_USER_ID + ") REFERENCES " + T_USERS + "(" + U_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_CLUB_MEMBERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_CLUBS);
        onCreate(db);
    }

    // ---------------- USERS ----------------
    public boolean addUser(String name, String email, String pass, String role) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_NAME, name);
        cv.put(U_EMAIL, email);
        cv.put(U_PASS, pass);
        cv.put(U_ROLE, role);
        long id = -1;
        try {
            id = db.insertOrThrow(T_USERS, null, cv);
        } catch (SQLiteConstraintException e) {
            e.printStackTrace();
        }
        return id != -1;
    }

    public boolean checkUser(String email, String pass) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        boolean ok = false;
        try {
            c = db.query(T_USERS, null, U_EMAIL + "=? AND " + U_PASS + "=?",
                    new String[]{email, pass}, null, null, null);
            if (c != null && c.moveToFirst()) ok = true;
        } finally {
            if (c != null) c.close();
        }
        return ok;
    }

    public int getUserIdByEmail(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        int userId = -1;
        try {
            c = db.query(T_USERS, new String[]{U_ID}, U_EMAIL + "=?", new String[]{email}, null, null, null);
            if (c != null && c.moveToFirst()) {
                userId = c.getInt(c.getColumnIndexOrThrow(U_ID));
            }
        } finally {
            if (c != null) c.close();
        }
        return userId;
    }

    public String getUserRoleById(int userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        String role = null;
        try {
            c = db.query(T_USERS, new String[]{U_ROLE}, U_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);
            if (c != null && c.moveToFirst()) role = c.getString(c.getColumnIndexOrThrow(U_ROLE));
        } finally {
            if (c != null) c.close();
        }
        return role;
    }


    // ---------------- CLUB MEMBERS ----------------
    public boolean requestToJoin(int clubId, int userId) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.query(T_CLUB_MEMBERS, null,
                CM_CLUB_ID + "=? AND " + CM_USER_ID + "=?",
                new String[]{String.valueOf(clubId), String.valueOf(userId)}, null, null, null);
        boolean exists = (c != null && c.moveToFirst());
        if (c != null) c.close();
        if (exists) return false;

        ContentValues cv = new ContentValues();
        cv.put(CM_CLUB_ID, clubId);
        cv.put(CM_USER_ID, userId);
        cv.put(CM_STATUS, STATUS_PENDING);
        long id = db.insert(T_CLUB_MEMBERS, null, cv);
        return id != -1;
    }

    public List<MemberRequest> getPendingMembers(int clubId) {
        List<MemberRequest> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        try {
            c = db.query(T_CLUB_MEMBERS, null, CM_CLUB_ID + "=? AND " + CM_STATUS + "=?",
                    new String[]{String.valueOf(clubId), STATUS_PENDING}, null, null, null);
            if (c != null) {
                while (c.moveToNext()) {
                    list.add(new MemberRequest(
                            c.getInt(c.getColumnIndexOrThrow(CM_CLUB_ID)),
                            c.getInt(c.getColumnIndexOrThrow(CM_USER_ID)),
                            c.getString(c.getColumnIndexOrThrow(CM_STATUS))
                    ));
                }
            }
        } finally {
            if (c != null) c.close();
        }
        return list;
    }

    public boolean approveMember(int clubId, int userId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(CM_STATUS, STATUS_APPROVED);
        int rows = db.update(T_CLUB_MEMBERS, cv, CM_CLUB_ID + "=? AND " + CM_USER_ID + "=?",
                new String[]{String.valueOf(clubId), String.valueOf(userId)});
        return rows > 0;
    }

    // ---------------- CLUBS ----------------
    public Club getClubById(int clubId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = null;
        Club club = null;
        try {
            c = db.query(T_CLUBS, null, C_ID + "=?", new String[]{String.valueOf(clubId)}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int id = c.getInt(c.getColumnIndexOrThrow(C_ID));
                String name = c.getString(c.getColumnIndexOrThrow(C_NAME));
                String desc = c.getString(c.getColumnIndexOrThrow(C_DESC));
                 int logo=0;
                club = new Club(name,desc,logo);
            }
        } finally {
            if (c != null) c.close();
        }
        return club;
    }
}