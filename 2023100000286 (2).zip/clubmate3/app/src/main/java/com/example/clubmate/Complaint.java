package com.example.clubmate;

public class Complaint {
    private int id;
    private int clubId;
    private int userId;
    private String text;
    private long date; // changed from String to long

    // No-arg constructor
    public Complaint() {}

    // Constructor with all fields
    public Complaint(int id, int clubId, int userId, String text, long date) {
        this.id = id;
        this.clubId = clubId;
        this.userId = userId;
        this.text = text;
        this.date = date;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClubId() { return clubId; }
    public void setClubId(int clubId) { this.clubId = clubId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public long getDate() { return date; }
    public void setDate(long date) { this.date = date; }

    @Override
    public String toString() {
        return "UserID: " + userId + ", ClubID: " + clubId + ", Date: " + date + ", Text: " + text;
    }
}


