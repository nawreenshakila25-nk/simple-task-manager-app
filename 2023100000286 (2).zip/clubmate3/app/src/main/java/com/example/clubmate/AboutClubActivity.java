package com.example.clubmate;
import android.content.Intent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AboutClubActivity extends AppCompatActivity {

    TextView tvClubTitle, tvClubNameBig, tvClubDescription;
    ImageView ivAboutLogo;
    Button btnJoinClub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_club);

        // Find views
        tvClubTitle = findViewById(R.id.tvClubTitle);
        tvClubNameBig = findViewById(R.id.tvClubName);
        tvClubDescription = findViewById(R.id.tvClubDescription);
        ivAboutLogo = findViewById(R.id.ivClubLogo);
        btnJoinClub = findViewById(R.id.btnJoinClub);

        // Get data from Intent
        String clubName = getIntent().getStringExtra("clubName");
        String clubDesc = getIntent().getStringExtra("clubDescription");
        int clubLogoRes = getIntent().getIntExtra("clubLogo", R.drawable.ic_launcher_foreground);


        // Populate UI
        tvClubNameBig.setText(clubName);
        tvClubDescription.setText(clubDesc);
        ivAboutLogo.setImageResource(clubLogoRes);


        btnJoinClub.setOnClickListener(v -> {
            Intent intent = new Intent(AboutClubActivity.this, EnrollActivity.class);
            intent.putExtra("clubName", tvClubNameBig.getText().toString());
            startActivity(intent);
        });
    }
}

