package com.example.clubmate;

import android.os.Bundle;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MembersActivity extends AppCompatActivity {

    DBHelper db;
    Spinner spClubs;
    RecyclerView rvMembers;
    MemberAdapter adapter;
    List<MemberRequest> memberList = new ArrayList<>();
    List<Club> clubList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_members);

        db = new DBHelper(this);

        spClubs = findViewById(R.id.spClubs);
        rvMembers = findViewById(R.id.rvMembers);

        // Setup RecyclerView
        rvMembers.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MemberAdapter(this, memberList, member -> {
            // Approve member
            boolean ok = db.approveMember(member.getClubId(), member.getUserId());
            if (ok) {
                Toast.makeText(this, "Member approved", Toast.LENGTH_SHORT).show();
                loadMembers(); // refresh
            } else {
                Toast.makeText(this, "Failed to approve", Toast.LENGTH_SHORT).show();
            }
        });
        rvMembers.setAdapter(adapter);

        // When user selects a club, load pending members
        spClubs.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                loadMembers();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
                memberList.clear();
                adapter.notifyDataSetChanged();
            }
        });
    }


    private void loadMembers() {
        int pos = spClubs.getSelectedItemPosition();
        if (pos < 0 || pos >= clubList.size()) return;

        int clubId = clubList.get(pos).getLogoResId();
        memberList.clear();
        memberList.addAll(db.getPendingMembers(clubId));
        adapter.notifyDataSetChanged();
    }
}

