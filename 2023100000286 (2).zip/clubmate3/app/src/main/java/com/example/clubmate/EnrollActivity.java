package com.example.clubmate;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EnrollActivity extends AppCompatActivity {

    EditText etName, etEmail;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Use your XML layout name here
        setContentView(R.layout.enroll_form);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();

            if (name.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // TODO: save enrollment info
            Toast.makeText(this, "Enrollment submitted for " + name, Toast.LENGTH_SHORT).show();
            // Go to Payment Methods page
            Intent intent = new Intent(EnrollActivity.this, PaymentMethodActivity.class);
            startActivity(intent);
            finish(); // close this page
        });
    }
}


