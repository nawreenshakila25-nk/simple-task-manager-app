package com.example.clubmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DashboardActivity extends AppCompatActivity {

    CardView cardClubs;
    FloatingActionButton fabAdd;
    DBHelper db;
    String email;
    int userId;
    String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DBHelper(this);

        // get logged in user info
        email = getIntent().getStringExtra("email");
        userId = getIntent().getIntExtra("userId", -1);

        if (email == null || userId == -1) {
            Toast.makeText(this, "Login error", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // fetch role
        role = db.getUserRoleById(userId);
        if (role == null) role = "Member";

        // find views
        cardClubs = findViewById(R.id.cardClubs);
        fabAdd = findViewById(R.id.fabAdd);

        // Clubs card click
        cardClubs.setOnClickListener(v -> {
            Intent i = new Intent(DashboardActivity.this, ClubListActivity.class);
            startActivity(i);
        });

        // You can keep fabAdd logic if needed
        fabAdd.setOnClickListener(v -> {
            // Add your action here
        });
    }
}
