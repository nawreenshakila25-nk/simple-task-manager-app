package com.example.clubmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentInfoActivity extends AppCompatActivity {

    TextView tvPaymentMethod;
    EditText etAccountNumber, etAmount;
    Button btnProceed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_info);

        tvPaymentMethod = findViewById(R.id.tvPaymentMethod);
        etAccountNumber = findViewById(R.id.etAccountNumber);
        etAmount = findViewById(R.id.etAmount);
        btnProceed = findViewById(R.id.btnProceed);

        // Get payment method from previous activity
        String paymentMethod = getIntent().getStringExtra("paymentMethod");
        if (paymentMethod != null) {
            tvPaymentMethod.setText("Payment Method: " + paymentMethod);
        }

        btnProceed.setOnClickListener(v -> {
            String account = etAccountNumber.getText().toString().trim();
            String amount = etAmount.getText().toString().trim();

            if (account.isEmpty() || amount.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Optional: validate account/amount here

            // Go to PaymentSuccessActivity
            Intent intent = new Intent(PaymentInfoActivity.this, PaymentSuccessActivity.class);
            startActivity(intent);
            finish(); // close payment info page
        });
    }
}
